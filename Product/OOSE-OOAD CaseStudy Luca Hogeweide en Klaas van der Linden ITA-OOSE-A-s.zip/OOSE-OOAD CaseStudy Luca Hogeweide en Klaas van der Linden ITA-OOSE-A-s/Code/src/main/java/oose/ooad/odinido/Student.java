package oose.ooad.odinido;


public class Student extends Uitvoerende {



    public Student(String studentnaam) {
        super(studentnaam);
    }


}
