package oose.ooad.odinido;

public class TekstAntwoord {
    private String tekstAntwoord;

    public TekstAntwoord(String tekstAntwoord){
        this.tekstAntwoord = tekstAntwoord;
    }

    public String getTekstAntwoord() {
        return tekstAntwoord;
    }
}
